from pydantic import BaseModel
from typing import Optional
import datetime

class InstrumentCreate(BaseModel):
    symbol: str
    name: Optional[str] = None

class TransactionCreate(BaseModel):
    account_id: int
    instrument_id: Optional[int] = None
    amount: float
    currency: Optional[str] = 'INR'

class TransactionOut(BaseModel):
    id: int
    account_id: int
    instrument_id: Optional[int]
    amount: float
    currency: str
    timestamp: datetime.datetime

    class Config:
        orm_mode = True

class PortfolioValue(BaseModel):
    total_value: float
    breakdown: dict
