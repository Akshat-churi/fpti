from . import models
from sqlalchemy.orm import Session

def create_user(db: Session, name: str):
    u = models.User(name=name)
    db.add(u)
    db.commit()
    db.refresh(u)
    return u

def get_transactions(db: Session):
    return db.query(models.Transaction).order_by(models.Transaction.timestamp).all()

def add_transaction(db: Session, txn: models.Transaction):
    db.add(txn)
    db.commit()
    db.refresh(txn)
    return txn

def compute_portfolio_value(db: Session, market_price_lookup):
    from collections import defaultdict
    holdings = defaultdict(float)
    cash = 0.0
    txns = db.query(models.Transaction).all()
    for t in txns:
        if t.instrument and t.instrument.symbol:
            holdings[t.instrument.symbol] += t.amount
        else:
            cash += t.amount

    breakdown = {}
    total = cash
    for sym, qty in holdings.items():
        price = market_price_lookup(sym)
        value = qty * price
        breakdown[sym] = {'quantity': qty, 'price': price, 'value': value}
        total += value

    return {'total_value': total, 'cash': cash, 'breakdown': breakdown}
