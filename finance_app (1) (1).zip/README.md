# Finance App (FastAPI + Dash)

This is a minimal full-stack finance tracking application.

## Features
- Backend: FastAPI with SQLite (via SQLAlchemy ORM)
- Frontend: Plotly Dash dashboard
- OOP models for Users, Accounts, Transactions, Instruments
- Async market price fetcher (mocked; replace with real API)
- Pandas used for data transformation
- Interactive charts for net worth timeline and asset allocation

## Setup Instructions

### 1. Create a virtual environment and install dependencies
```bash
python -m venv venv
source venv/bin/activate   # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Run the backend (FastAPI)
```bash
uvicorn backend.main:app --reload
```

The API will be available at: http://127.0.0.1:8000

### 3. Run the frontend (Dash)
```bash
python frontend/dash_app.py
```

The dashboard will be available at: http://127.0.0.1:8050

## API Endpoints

- `GET /api/portfolio/value` → Portfolio total value and breakdown
- `GET /api/transactions` → List transactions
- `POST /api/transactions` → Add a transaction
- `POST /api/instruments` → Add an instrument
- `GET /api/markets/{symbol}` → Fetch current (mocked) market price

## Next Steps
- Replace mocked market price fetcher with real API (e.g., Alpha Vantage, Finnhub).
- Store proper share quantities and purchase prices in `Transaction` model.
- Add authentication (JWT/OAuth2).
- Add Monte Carlo simulations for projections.
- Containerize with Docker for deployment.
